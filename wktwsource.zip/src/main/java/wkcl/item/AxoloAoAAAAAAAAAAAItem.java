
package wkcl.item;

import wkcl.itemgroup.WkTweakItemGroup;

import wkcl.WktweaksModElements;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.util.ResourceLocation;
import net.minecraft.item.Rarity;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;

@WktweaksModElements.ModElement.Tag
public class AxoloAoAAAAAAAAAAAItem extends WktweaksModElements.ModElement {
	@ObjectHolder("wktweaks:axolo_ao_aaaaaaaaaaa")
	public static final Item block = null;
	public AxoloAoAAAAAAAAAAAItem(WktweaksModElements instance) {
		super(instance, 5);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new MusicDiscItemCustom());
	}
	public static class MusicDiscItemCustom extends MusicDiscItem {
		public MusicDiscItemCustom() {
			super(0, (net.minecraft.util.SoundEvent) ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.fox.spit")),
					new Item.Properties().group(WkTweakItemGroup.tab).maxStackSize(1).rarity(Rarity.RARE));
			setRegistryName("axolo_ao_aaaaaaaaaaa");
		}

		@Override
		@OnlyIn(Dist.CLIENT)
		public boolean hasEffect(ItemStack itemstack) {
			return true;
		}
	}
}
